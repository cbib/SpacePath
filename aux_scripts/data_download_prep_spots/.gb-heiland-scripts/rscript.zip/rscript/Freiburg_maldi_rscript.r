# Preprocess raw Spatial metabo data (imzML + ibd)
# @authors:  Henrik Heiland and Jan Kückelhaus from theMILOlab
# https://github.com/theMILOlab/Code_Request/blob/abd61a05f634333975e8342220633faaac8929fa/MALDI.R
# ** All the 6 patients are present in the same imzML file kidnly provided by Dr Heiland**
# this script split into the 6 slices (this is THEIR script)
# 
library(tidyverse)
library(ggplot2)

require(EBImage, lib.loc = "/home/johanna/micromamba/envs/r_spatial/lib/R/library")
library(Cardinal)
library(sva)
#library(monocle3)
library(MALDIquant)
library(SPATA2)

NN <- 10  # the k for KNN function
file_m <- "/mnt/cbib/thesis_gbm/spatial_thesis/RaviHeiland-data-and-Rscripts/Freiburg_data/MALDI_CC/imzML_file/20201029scilslab_ncfr_glia_combine_root_mean_square.imzML"
out_dir <- "/mnt/cbib/thesis_gbm/spatial_thesis/RaviHeiland-data-and-Rscripts/"
file_annotations <- "/mnt/cbib/thesis_gbm/spatial_thesis/RaviHeiland-data-and-Rscripts/Freiburg_data/MALDI_CC/Images and metaspace annotation/Metaspace_annotations_943peaks.tsv"
data2 <- Cardinal::readMSIData(file_m)
data2
plot(data2, pixel=c(700,700)) # the spectrum of this x,y pixel

anno <- read.csv(file_annotations, sep="\t", header=TRUE)

# No lactate peak in the list : Metaspace_annotations....xlsx
# only peaks superior to 124 are annotated, however
# moleculeNames column display too many candidates per m/z peak. This is bad.

# # Plot some m/z by hand: 
# Note: All the 6 patients slices are displayed in each single plot:
image(data2, mz=191)  # citric acid 191
image(data2, mz=215) # glucose 
image(data2, mz=146) # glutamate

image(data2, mz=110) # not in the list; peaks inferior to 100 not informative 

# see https://github.com/theMILOlab/Code_Request MALDI.R code

image_data <- pixelData(data2) %>% as.data.frame()

# split the whole object (matrix like) into 6 equal parts:
image_data$Breaks=1
count=1
for(i in 2:nrow(image_data)){
  
  if(c(image_data$y[i]-image_data$y[i-1])>=2 | c(image_data$y[i]-image_data$y[i-1])<=c(-2) ){
    count=count+1
    image_data$Breaks[i]=count
    message(count)
  }else{image_data$Breaks[i]=count}
  
}

mz <- data2@featureData@mz
spectra <- as.matrix(spectraData(data2)[[1]])
rownames(spectra) <- mz
annotation <- data.frame(mz=as.numeric(rownames(spectra)), anno=0)


# joha's add ---
# pca without batch correction
var0 <- data.frame(row=rownames(spectra), var0=apply(spectra,1,stats::var)) %>% top_n(., 1000, var0)
most.var.spectra0 <- spectra[var0$row, ]

#Cluster and DimRed

#PCA WITHOUT BATCH EFFECT CORRECTION
pca0 <- irlba::prcomp_irlba(most.var.spectra0, n=30)$rotation %>% as.data.frame()

pca.plot0 <- pca0 %>% mutate(barcodes=colnames(spectra),samples=as.factor(image_data$Breaks))

pdf(paste0(out_dir, "pca_batch_NOTcorrected.pdf"))
ggplot(data=pca.plot0, aes(x=PC1+PC2, y=PC3, color=samples))+
  geom_point(size=0.2, alpha=0.5)+
  SPATA2::scale_color_add_on(variable = "character",clrp = "milo")+ 
  theme_classic() + ggtitle("PCA without batch effect correction")
dev.off()

# end joha's add --


# batch effect removal

spectra.batch <- sva::ComBat(spectra, image_data$Breaks)

# Dimensional reduction and Clustering:

#select 1000 most variable
var <- data.frame(row=rownames(spectra.batch), var=apply(spectra.batch,1,var)) %>% top_n(., 1000, var)
most.var.spectra <- spectra.batch[var$row, ]

#Cluster and DimRed

#PCA
pca <- irlba::prcomp_irlba(most.var.spectra, n=30)$rotation %>% as.data.frame()

pca.plot <- pca %>% mutate(barcodes=colnames(spectra.batch),samples=as.factor(image_data$Breaks))

pdf(paste0(out_dir, "pca_batch_corrected.pdf"))
ggplot(data=pca.plot, aes(x=PC1+PC2, y=PC3, color=samples))+
  geom_point(size=0.2, alpha=0.5)+
  SPATA2::scale_color_add_on(variable = "character",clrp = "milo")+ 
  theme_classic() + ggtitle("PCA after batch effect correction")
dev.off()

# TODO: consider computing other alternative to PCA, e.g. OPLS  ?

#Graph Clustering  

nearest <- RANN::nn2(pca, k = NN, treetype = "bd", searchtype = "priority")
saveRDS(nearest, file=paste0(out_dir, "nearest_RANN_out.rds"))

nearest$nn.idx <- nearest$nn.idx
nearest$nn.dists <- nearest$nn.dists
edges = reshape2::melt(t(nearest$nn.idx[, 1:NN]))
base::colnames(edges) = c("B", "A", "C")
edges = edges[, c("A", "B", "C")]
edges$B = edges$C
edges$C = 1
edges = base::unique(base::transform(edges, A = pmin(A, B), B = pmax(A, B)))
names(edges) <- c("V1", "V2", "weight")
edges$V1 <- base::rownames(pca)[edges$V1]
edges$V2 <- base::rownames(pca)[edges$V2]
g <- igraph::graph.data.frame(edges, directed = F)
graph.out = igraph::cluster_louvain(g)
clust.assign = base::factor(graph.out$membership, levels = base::sort(base::unique(graph.out$membership)))
Cluster_out=base::data.frame(ID=base::rownames(pca), Cluster=clust.assign, samples=image_data$Breaks); base::rownames(Cluster_out)=Cluster_out$ID

saveRDS(Cluster_out, file=paste0(out_dir, "whole_clus_out.rds"))
saveRDS(pca, file=paste0(out_dir, "whole_pca.rds"))

# TODO: use this pca_with_cluster_colors in a new script to plot it . then remove from here
# # Add cluster to plot df  ---> this is uncomplete ! not functional
# pdf(paste0(out_dir, "pca_clusters.pdf"))
# pca_with_cluster_colors <- 
#    pca %>% 
#    mutate(barcodes=colnames(spectra.batch),
#           samples=as.factor(image_data$Breaks),
#           Cluster=clust.assign
#    )
# dev.off()


umap <- umap::umap(pca)
UMAP <- base::data.frame(barcodes=base::rownames(pca),
                         samples=image_data$Breaks,
                         cluster=Cluster_out$Cluster,
                         umap1=umap$layout[,1], 
                         umap2=umap$layout[,2])

saveRDS(UMAP, file=paste0(out_dir, "whole_clus_UMAP.rds"))

#Run TSNE
TSNE = Rtsne::Rtsne(pca, perplexity=50)
TSNE_o <- base::data.frame(barcodes=base::rownames(pca),
                           samples=image_data$Breaks,
                           #cluster=Cluster_out$Cluster,
                           tsne1=TSNE$Y[,1], tsne2=TSNE$Y[,2])
saveRDS(TSNE, file=paste0(out_dir, "whole_TSNE.rds"))


#Plot Dim Red

col_use <- colorRampPalette(confuns::clrp_milo)(23)

confuns::all_colorpanels()
pdf(paste0(out_dir, "plot_tsne_clusters"))
ggplot(TSNE_o, aes(x=tsne1, y=tsne2, color=as.character(Cluster_out$samples))) + 
  geom_point(size=0.1, alpha=0.5)+theme_classic()+xlim(-10,12)
ggplot(TSNE_o, aes(x=tsne1, y=tsne2, color=as.character(TSNE_o$samples)))+
  geom_point(size=0.2, alpha=0.5)+theme_classic()+
  scale_color_manual(values=col_use)
dev.off()

cat("*-* Ended PCA UMAP and TSNE *-*")
cat("\n")

# # Better Performance in Batch Effect removal using Monocle3

# #Create a cds file
# 
# fdata <- image_data %>% tibble::rownames_to_column("row_ID") %>% mutate(sample=paste0("ID_S",Breaks,"_ID",row_ID))
# expression_matrix=spectra.batch
# class(expression_matrix)
# dim(expression_matrix)
# colnames(expression_matrix) <- fdata$sample
# gene_metadata = data.frame(gene_short_name=rownames(expression_matrix));rownames(gene_metadata)=rownames(expression_matrix)
# cell_metadata=data.frame(barcodes=fdata$sample, sample=paste0("sample_", fdata$Breaks)); rownames(cell_metadata)=fdata$sample
# class(cell_metadata)
# cell_metadata$sample=as.factor(cell_metadata$sample)
# table(rownames(cell_metadata) %in% colnames(expression_matrix))
# 
# cds <- monocle3::new_cell_data_set(expression_matrix,
#                          cell_metadata = cell_metadata,
#                          gene_metadata = gene_metadata)
# cds=cds[,Matrix::colSums(exprs(cds)) != 0]
# 
# #Process and Plot TSNE
# 
# cds <- estimate_size_factors(cds)
# cds <- preprocess_cds(cds, preprocess_method="PCA", num_dim = 15)
# cds <- align_cds(cds, alignment_group = "sample")
# cds <- preprocess_cds(cds, preprocess_method="PCA", num_dim = 15)
# cds <- reduce_dimension(cds,reduction_method="tSNE", cores=4)
# cds <- reduce_dimension(cds)
# cds <- cluster_cells(cds,cluster_method="louvain")
# col_use <- colorRampPalette(confuns::clrp_milo)(24)
# plot_cells(cds, reduction_method="tSNE", color_cells_by="sample", label_cell_groups=F, cell_size=0.5)+scale_color_manual(values=col_use)


# Seperate Patients and Create SPATA file -------------------------------------------------------

#-------------------------Annotate Peaks to Metabolites

#-> Run all samples for SPATA object

samples_MALDI <- c("248_T", "259_T", "260_T", "262_T", "269_T", "275_T")

for(xx in 1:6){
  
  print(samples_MALDI[xx])
  
  Seperate <- image_data %>%
    tibble::rownames_to_column("row_ID") %>%
    dplyr::filter(Breaks==xx) %>%
    dplyr::mutate(sample=paste0("ID_S",Breaks,"_ID",row_ID))
  spectra_S1 <- as.data.frame(spectra.batch[,as.numeric(Seperate$row_ID)])
  spectra_S1 <- na.omit(spectra_S1)
  spectra_S1 <- spectra_S1[rowSums(spectra_S1)>0, ]
  
  
  #Function to replicate rows with similar peak annotations
  row_rep <- function(df, n) {
    df[rep(1:nrow(df), times = n),]
  }
  
  #Annotate
  
  match <- match.closest(anno$mz, as.numeric(rownames(spectra_S1))) 
  
  data_all_Spectra <- as.data.frame(do.call(rbind,pbapply::pblapply(1:nrow(anno), 
                                                                    function(i){
                                                                      MET=unlist(stringr::str_split(anno[i,]$moleculeIds, pattern=", "))
                                                                      data_out <-
                                                                        as.data.frame(spectra_S1[match[i], ,drop=F]) %>%
                                                                        'names<-'(colnames(spectra_S1)) %>%
                                                                        colSums() %>%
                                                                        as.data.frame() %>%
                                                                        t() %>%
                                                                        as.data.frame() %>%
                                                                        row_rep(., n=length(MET)) %>%
                                                                        mutate(HMDH=MET ) %>%
                                                                        select(HMDH, names(as.data.frame(spectra_S1[match[i], ,drop=F])))
                                                                      dim(data_out)
                                                                      return(data_out)
                                                                    })))
  dim(data_all_Spectra)
  data_all_Spectra <- data_all_Spectra[rowSums(data_all_Spectra[,2:ncol(data_all_Spectra)])>0, ]
  dim(data_all_Spectra)
  
  #Summarize Annotations
  duplicated <- data_all_Spectra[duplicated(data_all_Spectra$HMDH),"HMDH"]
  #remove=rownames((data_all_Spectra %>% filter(HMDH %in% duplicated)))
  data_all <- as.data.frame(do.call(rbind, pbapply::pblapply(1:length(duplicated), function(z){
    out <- data.frame(HMDH=duplicated[z], t(as.data.frame(colMeans(data_all_Spectra %>% filter(HMDH==duplicated[z]) %>% select(!HMDH) ))) )
    rownames(out)=NULL
    return(out)
  })))
  data_all.dt <- rbind(data_all, data_all_Spectra %>% filter(!(HMDH %in% duplicated)))
  
  
  rows <- data_all.dt$HMDH
  data_all.dt$HMDH <- NULL
  rownames(data_all.dt) <- rows
  data_all <- data_all.dt %>% as.matrix()
  
  #Coordinate File
  S1 <- image_data %>% tibble::rownames_to_column("row_ID") %>% dplyr::filter(Breaks==xx) %>% mutate(sample=paste0("ID_S",Breaks,"_ID",row_ID))
  coordinates <- data.frame(barcodes=S1$sample,sample=paste0("Sample_",S1$Breaks), 
                            x=as.numeric(S1$x), 
                            y=as.numeric(S1$y))
  
  colnames(data_all) = coordinates$barcodes
  S1_object <-  SPATA2::initiateSpataObject_ExprMtr(coords_df=coordinates,
                                                    expr_mtr=data_all,
                                                    spatial_method = "Unknown",
                                                    mtr_name = "Metabolites",
                                                    sample_name = samples_MALDI[xx]
  )
  
  #saveRDS(S1_object, file = paste0(out_dir, "MALDI_",samples_MALDI[xx],".rds"))
  
  # save the matrix as tsv
  write.table(S1_object@data[[samples_MALDI[xx]]][["Metabolites"]], 
              file.path(mydir, "Freiburg_data_tables", "annotated",
                        paste0("MALDI_", samples_MALDI[xx], ".tsv")), sep='\t')
  
  # save the coordinates as tsv
  head(S1_object@coordinates[[1]])
  write.table(S1_object@coordinates[[1]], 
              file.path(mydir, "Freiburg_data_tables", "annotated",
                        paste0("coords_", samples_MALDI[xx], ".tsv")), sep='\t')
  
}

